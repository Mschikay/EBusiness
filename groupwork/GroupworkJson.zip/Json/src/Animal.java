
public class Animal {
	String species;
	String food;
	
	public Animal(String species, String state) {
		this.species = species;
		this.food = state;
	}
}
