package com.booking.model;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class RestRoom {
	
	private String name;

	private int restCount;
	
	public RestRoom () { }
	
	public RestRoom (String name, int restCount) { 
		this.name = name;
		this.restCount = restCount;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRestCount() {
		return restCount;
	}

	public void setRestCount(int restCount) {
		this.restCount = restCount;
	}
	
}
