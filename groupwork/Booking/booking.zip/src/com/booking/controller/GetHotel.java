package com.booking.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import com.booking.model.*;

@ManagedBean(name = "getHotel", eager = true)
@SessionScoped
public class GetHotel {
	
	private List <Hotel> hotels;
	private RootDb rootdb;
	
	public GetHotel() throws Exception {
		this.hotels = new ArrayList<>();
		this.rootdb = RootDb.getInstance();
	}

	public String displayAvailableHotels(String checkin, String checkout, String addrTemp, String people) throws Exception {
		this.hotels.clear();
		try {
			Date checkinTemp = Date.valueOf(checkin);
			Date checkoutTemp = Date.valueOf(checkout);
			int peopleTemp = Integer.parseInt(people);
			
			this.hotels = rootdb.getAvailable(checkinTemp, checkoutTemp, addrTemp, peopleTemp);
			
			ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();		

			Map<String, Object> requestMap = externalContext.getRequestMap();
			requestMap.put("hotels", this.hotels);	
			

		}catch (Exception e) {
			e.getMessage();
		}
		return "/hotel.xhtml";
	}
	
}
